﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketingSystem.DB.Database;
using TicketingSystem.DB.DBManagers;

namespace TicketingSystem.DB
{
    public class DBManager
    {
        public static void TestMethod()
        {

            using (DatabaseContext context = new DatabaseContext())
            {
                context._Users.Add(new _User()
                {
                    _Email = "vainktesh.kumar@technovert.com",
                    _Name = "Vainktesh Kumar",
                    _EmployeeId = "1423"
                });

                context.SaveChanges();
            }
            //TicketDBManager t = new TicketDBManager();
            //var x = t.GetTicketById(3);
        }
    }
}
