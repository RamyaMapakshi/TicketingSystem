﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketingSystem.DB.DBManagers
{
    public class AttachmentDBManager
    {

        public bool UpsertAttachment(ViewModel.Attachment attachment)
        {
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                Database._Attachment attachmentToUpsert = new Database._Attachment();
                attachmentToUpsert._ID = attachment.ID;
                attachmentToUpsert._FileName = attachment.FileName;
                attachmentToUpsert._FileUrl = attachment.FileUrl;
                attachmentToUpsert._UploadedBy = attachment.UploadedBy.ID;
                attachmentToUpsert._Ticket = attachment.TicketId;
                if (attachment.ID == 0)
                {
                    context._Attachments.Add(attachmentToUpsert);
                }
                return Convert.ToBoolean(context.SaveChanges());
            }
        }
        public List<ViewModel.Attachment> GetAllAttachmentsForATicket(int ticketId)
        {
            List<ViewModel.Attachment> attachmentsForTheTicket = new List<ViewModel.Attachment>();
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                foreach (var attachment in context._Attachments.Where(x => x._Ticket == ticketId).ToList())
                {
                    attachmentsForTheTicket.Add(ConvertDBAttachmentModelToViewModelAttachment(attachment));
                }
            }

            return attachmentsForTheTicket;
        }
        public List<ViewModel.Attachment> GetAllAttachments()
        {
            List<ViewModel.Attachment> attachments = new List<ViewModel.Attachment>();
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                foreach (var attachment in context._Attachments)
                {
                    attachments.Add(ConvertDBAttachmentModelToViewModelAttachment(attachment));
                }
            }

            return attachments;
        }

        public ViewModel.Attachment ConvertDBAttachmentModelToViewModelAttachment(Database._Attachment attachment)
        {
            return new ViewModel.Attachment()
            {
                FileName = attachment._FileName,
                FileUrl = attachment._FileUrl,
                ID = attachment._ID,
                UploadedBy = (ViewModel.User)attachment._User,
                TicketId = attachment._Ticket

            };
        }

    }
}
