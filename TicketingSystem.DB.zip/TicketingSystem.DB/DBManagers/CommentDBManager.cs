﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketingSystem.DB.DBManagers
{
    public class CommentDBManager
    {
        public bool UpsertComment(ViewModel.Comment comment)
        {
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                Database._Comment commentToUpsert = new Database._Comment();
                commentToUpsert._ID = comment.ID;
                commentToUpsert._IsPrivate = comment.IsPrivate;
                commentToUpsert._Modified = DateTime.Now;
                commentToUpsert._ModifiedBy = comment.ModifiedBy.ID;
                commentToUpsert._Ticket = comment.TicketId;
                if (comment.ID == 0)
                {
                    commentToUpsert._Created = DateTime.Now;
                    commentToUpsert._CreatedBy = comment.CreatedBy.ID;
                    context._Comments.Add(commentToUpsert);
                }
                return Convert.ToBoolean(context.SaveChanges());
            }
        }
        public List<ViewModel.Comment> GetAllcommentsForATicket(int ticketId)
        {
            List<ViewModel.Comment> commentsForTheTicket = new List<ViewModel.Comment>();
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                foreach (var comment in context._Comments.Where(x => x._Ticket == ticketId).ToList())
                {
                    commentsForTheTicket.Add(ConvertDBCommentModelToViewModelComment(comment));
                }
            }

            return commentsForTheTicket;
        }

        private ViewModel.Comment ConvertDBCommentModelToViewModelComment(Database._Comment comment)
        {
            UserManager userManager = new UserManager();
            return new ViewModel.Comment()
            {
                ID = comment._ID,
                Created = comment._Created,
                Modified = comment._Modified,
                IsPrivate = comment._IsPrivate,
                Details = comment._Details,
                CreatedBy = (ViewModel.User)comment._User,
                ModifiedBy = (ViewModel.User)comment._User1
            };
        }
    }
}
