﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketingSystem.DB.DBManagers
{
    public class CommonDBManager
    {
        public List<ViewModel.Priority> GeAllPriorities()
        {
            List<ViewModel.Priority> priorities = new List<ViewModel.Priority>();
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {

                foreach (var priority in context._Priorities)
                {
                    priorities.Add(new ViewModel.Priority() {
                        ID = priority._ID,
                        Color = priority._Color,
                        DaysDue = priority._DaysDue,
                        Description = priority._Description,
                        Title = priority._Title
                    });
                }
                return priorities;
            }
        }
        public List<ViewModel.Category> GeAllCategories()
        {
            List<ViewModel.Category> categories = new List<ViewModel.Category>();
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {

                foreach (var category in context._Categories)
                {
                    categories.Add(new ViewModel.Category()
                    {
                        ID = category._ID,
                        Description = category._Description,
                        Title = category._Title
                    });
                }
                return categories;
            }
        }
        public List<ViewModel.Status> GeAllStatus()
        {
            List<ViewModel.Status> status = new List<ViewModel.Status>();
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {

                foreach (var s in context._Status)
                {
                    status.Add(new ViewModel.Status()
                    {
                        ID = s._ID,
                        Description = s._Description,
                        Title = s._Title
                    });
                }
                return status;
            }
        }
        public List<ViewModel.TicketType> GeAllTicketTypes()
        {
            List<ViewModel.TicketType> types = new List<ViewModel.TicketType>();
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {

                foreach (var tt in context._TicketTypes)
                {
                    types.Add(new ViewModel.TicketType()
                    {
                        ID = tt._ID,
                        Description = tt._Description,
                        Title = tt._Title
                    });
                }
                return types;
            }
        }
        public bool UpsertTicketType(ViewModel.TicketType ticketType)
        {
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                Database._TicketType ticketTypeToUpsert = new Database._TicketType();
                ticketTypeToUpsert._ID = ticketType.ID;
                ticketTypeToUpsert._Title = ticketType.Title;
                ticketTypeToUpsert._Description = ticketType.Description;

                if (ticketType.ID == 0)
                {
                    context._TicketTypes.Add(ticketTypeToUpsert);
                }
                return Convert.ToBoolean(context.SaveChanges());
            }
        }
        public bool UpsertStatus(ViewModel.Status status)
        {
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                Database._Status statusToUpdate = new Database._Status();
                statusToUpdate._ID = status.ID;
                statusToUpdate._Title = status.Title;
                statusToUpdate._Description = status.Description;

                if (status.ID == 0)
                {
                    context._Status.Add(statusToUpdate);
                }
                return Convert.ToBoolean(context.SaveChanges());
            }
        }
        public bool UpsertCategory(ViewModel.Category category)
        {
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                Database._Category categoryToUpsert = new Database._Category();
                categoryToUpsert._ID = category.ID;
                categoryToUpsert._Title = category.Title;
                categoryToUpsert._Description = category.Description;

                if (category.ID == 0)
                {
                    context._Categories.Add(categoryToUpsert);
                }
                return Convert.ToBoolean(context.SaveChanges());
            }
        }
        public bool UpsertPriority(ViewModel.Priority priority)
        {
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                Database._Priority priorityToUpsert = new Database._Priority();
                priorityToUpsert._ID = priority.ID;
                priorityToUpsert._Title = priority.Title;
                priorityToUpsert._Description = priority.Description;
                priorityToUpsert._DaysDue = priority.DaysDue;
                priorityToUpsert._Color = priority.Color;

                if (priority.ID == 0)
                {
                    context._Priorities.Add(priorityToUpsert);
                }
                return Convert.ToBoolean(context.SaveChanges());
            }
        }
        public ViewModel.Priority GetPriorityById(int id)
        {
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                var p = context._Priorities.FirstOrDefault(x => x._ID == id);
                return new ViewModel.Priority()
                {
                    ID = p._ID,
                    Color = p._Color,
                    DaysDue = p._DaysDue,
                    Description = p._Description,
                    Title = p._Title
                };
            }
        }


        public ViewModel.Category GetCategoryById(int id)
        {
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                var c = context._Categories.FirstOrDefault(x => x._ID == id);
                return new ViewModel.Category()
                {
                    ID = c._ID,
                    Description = c._Description,
                    Title = c._Title
                };
            }
        }
        public ViewModel.Status GetStatusById(int id)
        {
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                var s = context._Status.FirstOrDefault(x => x._ID == id);
                return new ViewModel.Status()
                {
                    ID = s._ID,
                    Description = s._Description,
                    Title = s._Title
                };
            }
        }
        public ViewModel.TicketType GetTicketTypeById(int id)
        {
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                var tt = context._TicketTypes.FirstOrDefault(x => x._ID == id);
                return new ViewModel.TicketType()
                {
                    ID = tt._ID,
                    Description = tt._Description,
                    Title = tt._Title
                };
            }
        }
    }
}
