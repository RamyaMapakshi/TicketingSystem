﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketingSystem.DB.DBManagers
{
    class TicketDBManager
    {
        private AttachmentDBManager attachmentDBManager = new AttachmentDBManager();
        private CommentDBManager commentDBManager = new CommentDBManager();
        private UserManager userManagaer = new UserManager();
        private CommonDBManager commonDBManager = new CommonDBManager();
        public int UpsertTicket(ViewModel.Ticket ticket)
        {
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                Database._Ticket ticketToUpsert = new Database._Ticket();
                ticketToUpsert._ID = ticket.ID;
                ticketToUpsert._AssignedTechnician = ticket.AssignedTechnician.ID;
                ticketToUpsert._Category = ticket.Category.ID;
                ticketToUpsert._ClosedBy = ticket.ClosedBy.ID;
                ticketToUpsert._ClosedDate = ticket.ClosedDate;
                ticketToUpsert._Description = ticket.Description;
                ticketToUpsert._DueDate = ticket.DueDate;
                ticketToUpsert._DuplicateTicketID = ticket.DuplicateTicketID;
                ticketToUpsert._ExpectedCompletionDate = ticket.ExpectedCompletionDate;
                ticketToUpsert._IsActive = ticket.IsActive;
                ticketToUpsert._IsDuplicate = ticket.IsDuplicate;
                ticketToUpsert._IsEscalated = ticket.IsEscalated;
                ticketToUpsert._IsTicketGeneratedViaEmail = ticket.IsTicketGeneratedViaEmail;
                ticketToUpsert._Modified = DateTime.Now;
                ticketToUpsert._ModifiedBy = ticket.ModifiedBy.ID;
                ticketToUpsert._Priority = ticket.Priority.ID;
                ticketToUpsert._RequestedBy = ticket.RequestedBy.ID;
                ticketToUpsert._ResolvedBy = ticket.ResolvedBy.ID;
                ticketToUpsert._ResolvedDate = ticket.ResolvedDate;
                ticketToUpsert._Status = ticket.Status.ID;
                ticketToUpsert._Type = ticket.Type.ID;
                ticketToUpsert._CreatedBy = ticket.CreatedBy.ID;
                ticketToUpsert._Created = ticket.Created;
                if (ticket.ID == 0)
                {
                    ticketToUpsert._CreatedBy = ticket.CreatedBy.ID;
                    ticketToUpsert._Created = DateTime.Now;
                    context._Tickets.Add(ticketToUpsert);
                }
                return context.SaveChanges();
            }
        }
        public ViewModel.Ticket GetTicketById(int id)
        {
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                return ConvertDBTicketToViewModelTicket(context._Tickets.FirstOrDefault(x => x._ID == id));
            }
        }
        public List<ViewModel.Ticket> GetAllTickets()
        {
            List<ViewModel.Ticket> tickets = new List<ViewModel.Ticket>();
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                var status = commonDBManager.GeAllStatus();
                var priorities = commonDBManager.GeAllPriorities();
                var types = commonDBManager.GeAllTicketTypes();
                var categories = commonDBManager.GeAllCategories();
                //var attachments = attachmentDBManager
                foreach (var ticket in context._Tickets)
                {

                    //tickets.Add(ConvertDBTicketToViewModelTicket(ticket, userManagaer.GetAllUsers(), status, priorities, categories, types));
                }
                return tickets;
            }
        }
        private ViewModel.Ticket ConvertDBTicketToViewModelTicket(Database._Ticket ticket)
        {

            ViewModel.Ticket newTicket = null;
            if (ticket != null)
            {
                newTicket = new ViewModel.Ticket()
                {
                    ID = ticket._ID,
                    ClosedDate = ticket._ClosedDate,
                    Modified = ticket._Modified,
                    Created = ticket._Created,
                    IsTicketGeneratedViaEmail = ticket._IsTicketGeneratedViaEmail,
                    IsActive = ticket._IsActive,
                    IsDuplicate = ticket._IsDuplicate,
                    IsEscalated = ticket._IsEscalated,
                    Description = ticket._Description,
                    ExpectedCompletionDate = ticket._ExpectedCompletionDate,
                    DueDate = ticket._DueDate,
                    ResolvedDate = ticket._ResolvedDate,
                    DuplicateTicketID = ticket._DuplicateTicketID,
                    ClosedBy = ticket._User as ViewModel.User,
                    AssignedTechnician = ticket._User5 as ViewModel.User,
                    CreatedBy = ticket._User1 as ViewModel.User,
                    ModifiedBy = ticket._User2 as ViewModel.User,
                    RequestedBy = ticket._User3 as ViewModel.User,
                    ResolvedBy = ticket._User4 as ViewModel.User,
                    Category = ticket._Category1 as ViewModel.Category,
                    Priority = ticket._Priority1 as ViewModel.Priority,
                    Status = ticket._Status1 as ViewModel.Status,
                    Type = ticket._TicketType as ViewModel.TicketType,
                    Comments = ticket._Comment as List<ViewModel.Comment>,
                    Attachments = ticket._Attachment as List<ViewModel.Attachment>
                };
            }
            return newTicket;
        }
        private ViewModel.Ticket ConvertDBTicketToViewModelTicket(Database._Ticket ticket, List<ViewModel.User> users, List<ViewModel.Status> status, List<ViewModel.Priority> priorities, List<ViewModel.Category> categories, List<ViewModel.TicketType> types, List<ViewModel.Attachment> attachments, List<ViewModel.Comment> comments)
        {
            ViewModel.Ticket newTicket = null;
            if (ticket != null)
            {
                newTicket = new ViewModel.Ticket()
                {
                    ID = ticket._ID,
                    ClosedDate = ticket._ClosedDate,
                    Modified = ticket._Modified,
                    Created = ticket._Created,
                    IsTicketGeneratedViaEmail = ticket._IsTicketGeneratedViaEmail,
                    IsActive = ticket._IsActive,
                    IsDuplicate = ticket._IsDuplicate,
                    IsEscalated = ticket._IsEscalated,
                    Description = ticket._Description,
                    ExpectedCompletionDate = ticket._ExpectedCompletionDate,
                    DueDate = ticket._DueDate,
                    ResolvedDate = ticket._ResolvedDate,
                    DuplicateTicketID = ticket._DuplicateTicketID,
                    ClosedBy = users.FirstOrDefault(x => x.ID == ticket._ClosedBy),
                    AssignedTechnician = users.FirstOrDefault(x => x.ID == ticket._AssignedTechnician.Value),
                    CreatedBy = users.FirstOrDefault(x => x.ID == ticket._CreatedBy),
                    ModifiedBy = users.FirstOrDefault(x => x.ID == ticket._ModifiedBy),
                    RequestedBy = users.FirstOrDefault(x => x.ID == ticket._RequestedBy),
                    ResolvedBy = users.FirstOrDefault(x => x.ID == ticket._ResolvedBy.Value),
                    Category = categories.FirstOrDefault(x => x.ID == ticket._Category),
                    Priority = priorities.FirstOrDefault(x => x.ID == ticket._Priority),
                    Status = status.FirstOrDefault(x => x.ID == ticket._Status),
                    Type = types.FirstOrDefault(x => x.ID == ticket._Type),
                    Comments = comments,
                    Attachments = attachments
                };
            }
            return newTicket;
        }
    }
}
