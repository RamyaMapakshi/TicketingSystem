﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketingSystem.DB.DBManagers
{
    public class UserManager
    {
        public List<ViewModel.User> GetAllUsers()
        {
            List<ViewModel.User> users = new List<ViewModel.User>();
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                foreach (var user in context._Users)
                {
                    users.Add(ConvertDBUserToViewModelUser(user));
                }
            }
            return users;
        }
        public ViewModel.User GetUserById(int id)
        {
            using (Database.DatabaseContext context = new Database.DatabaseContext())
            {
                var user = context._Users.FirstOrDefault(x => x._ID == id);
                if (user == null)
                {
                    return null;
                }
                return ConvertDBUserToViewModelUser(user);
            }
        }
        public ViewModel.User ConvertDBUserToViewModelUser(Database._User user)
        {
            //return new ViewModel.User()
            //{
            //    ID = user.ID,
            //    Email = user.Email,
            //    EmployeeId = user.EmployeeId,
            //    Name = user.Name
            //};
            return (ViewModel.User)user;
        }
    }
}
