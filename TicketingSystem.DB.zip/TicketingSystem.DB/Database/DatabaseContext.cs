namespace TicketingSystem.DB.Database
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class DatabaseContext : DbContext
    {
        public DatabaseContext()
            : base("name=TicketingSystem")
        {
        }

        public virtual DbSet<_Attachment> _Attachments { get; set; }
        public virtual DbSet<_Category> _Categories { get; set; }
        public virtual DbSet<_Comment> _Comments { get; set; }
        public virtual DbSet<_EmailRule> _EmailRules { get; set; }
        public virtual DbSet<_Priority> _Priorities { get; set; }
        public virtual DbSet<_Status> _Status { get; set; }
        public virtual DbSet<_Ticket> _Tickets { get; set; }
        public virtual DbSet<_TicketType> _TicketTypes { get; set; }
        public virtual DbSet<_User> _Users { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<_Category>()
                .HasMany(e => e._Ticket)
                .WithRequired(e => e._Category1)
                .HasForeignKey(e => e._Category)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<_Priority>()
                .HasMany(e => e._Ticket)
                .WithRequired(e => e._Priority1)
                .HasForeignKey(e => e._Priority)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<_Status>()
                .HasMany(e => e._Ticket)
                .WithRequired(e => e._Status1)
                .HasForeignKey(e => e._Status)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<_Ticket>()
                .HasMany(e => e._Attachment)
                .WithRequired(e => e._Ticket1)
                .HasForeignKey(e => e._Ticket)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<_Ticket>()
                .HasMany(e => e._Comment)
                .WithRequired(e => e._Ticket1)
                .HasForeignKey(e => e._Ticket)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<_TicketType>()
                .HasMany(e => e._Ticket)
                .WithRequired(e => e._TicketType)
                .HasForeignKey(e => e._Type)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<_User>()
                .HasMany(e => e._Attachment)
                .WithRequired(e => e._User)
                .HasForeignKey(e => e._UploadedBy)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<_User>()
                .HasMany(e => e._Comment)
                .WithRequired(e => e._User)
                .HasForeignKey(e => e._CreatedBy)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<_User>()
                .HasMany(e => e._Comment1)
                .WithRequired(e => e._User1)
                .HasForeignKey(e => e._ModifiedBy)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<_User>()
                .HasMany(e => e._Ticket)
                .WithOptional(e => e._User)
                .HasForeignKey(e => e._AssignedTechnician);

            modelBuilder.Entity<_User>()
                .HasMany(e => e._Ticket1)
                .WithOptional(e => e._User1)
                .HasForeignKey(e => e._ClosedBy);

            modelBuilder.Entity<_User>()
                .HasMany(e => e._Ticket2)
                .WithRequired(e => e._User2)
                .HasForeignKey(e => e._CreatedBy)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<_User>()
                .HasMany(e => e._Ticket3)
                .WithRequired(e => e._User3)
                .HasForeignKey(e => e._ModifiedBy)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<_User>()
                .HasMany(e => e._Ticket4)
                .WithRequired(e => e._User4)
                .HasForeignKey(e => e._RequestedBy)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<_User>()
                .HasMany(e => e._Ticket5)
                .WithOptional(e => e._User5)
                .HasForeignKey(e => e._ResolvedBy);
        }
    }
}
