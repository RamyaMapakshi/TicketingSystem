namespace TicketingSystem.DB.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("_Attachment")]
    public partial class _Attachment
    {
        [Key]
        [Column("_ID")]
        public int _ID { get; set; }

        [Column("_FileName")]
        [Required]
        [StringLength(50)]
        public string _FileName { get; set; }

        [Column("_FileUrl")]
        [Required]
        public string _FileUrl { get; set; }

        [Column("_UploadedBy")]
        public int _UploadedBy { get; set; }

        [Column("_Ticket")]
        public int _Ticket { get; set; }

        [Column("_TicketId")]
        public int? _TicketId { get; set; }

        public virtual _Ticket _Ticket1 { get; set; }

        public virtual _User _User { get; set; }
    }
}
