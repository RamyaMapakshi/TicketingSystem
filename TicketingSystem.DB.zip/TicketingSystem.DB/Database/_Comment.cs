namespace TicketingSystem.DB.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("_Comment")]
    public partial class _Comment
    {
        [Key]
        [Column("_ID")]
        public int _ID { get; set; }

        [Column("_Details")]
        public string _Details { get; set; }

        [Column("_IsPrivate")]
        public bool? _IsPrivate { get; set; }

        [Column("_Created")]
        public DateTime _Created { get; set; }

        [Column("_Modified")]
        public DateTime _Modified { get; set; }

        [Column("_CreatedBy")]
        public int _CreatedBy { get; set; }

        [Column("_ModifiedBy")]
        public int _ModifiedBy { get; set; }

        [Column("_Ticket")]
        public int _Ticket { get; set; }

        [Column("_TicketId")]
        public int? _TicketId { get; set; }

        public virtual _Ticket _Ticket1 { get; set; }

        public virtual _User _User { get; set; }

        public virtual _User _User1 { get; set; }
    }
}
