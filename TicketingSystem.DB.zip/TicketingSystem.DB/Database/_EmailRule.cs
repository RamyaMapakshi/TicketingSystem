namespace TicketingSystem.DB.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("_EmailRule")]
    public partial class _EmailRule
    {
        [Key]
        [Column("_ID")]
        public int _ID { get; set; }

        [Column("_ExclusionRule")]
        [Required]
        public string _ExclusionRule { get; set; }

        [Column("_Type")]
        [Required]
        [StringLength(50)]
        public string _Type { get; set; }

        [Column("_ExceptionInRule")]
        public string _ExceptionInRule { get; set; }
    }
}
