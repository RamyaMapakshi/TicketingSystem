namespace TicketingSystem.DB.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("_Priority")]
    public partial class _Priority
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public _Priority()
        {
            _Ticket = new HashSet<_Ticket>();
        }

        [Key]
        [Column("_ID")]
        public int _ID { get; set; }

        [Column("_Title")]
        [Required]
        [StringLength(50)]
        public string _Title { get; set; }

        [Column("_Description")]
        public string _Description { get; set; }

        [Column("_DaysDue")]
        public int? _DaysDue { get; set; }

        [Column("_Color")]
        [StringLength(50)]
        public string _Color { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<_Ticket> _Ticket { get; set; }
    }
}
