namespace TicketingSystem.DB.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("_Ticket")]
    public partial class _Ticket
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public _Ticket()
        {
            _Attachment = new HashSet<_Attachment>();
            _Comment = new HashSet<_Comment>();
        }

        [Key]
        [Column("_ID")]
        public int _ID { get; set; }

        [Column("_RequestedBy")]
        public int _RequestedBy { get; set; }

        [Column("_Status")]
        public int _Status { get; set; }

        [Column("_Category")]
        public int _Category { get; set; }

        [Column("_Description")]
        public string _Description { get; set; }

        [Column("_Priority")]
        public int _Priority { get; set; }

        [Column("_DueDate")]
        public DateTime _DueDate { get; set; }

        [Column("_Type")]
        public int _Type { get; set; }

        [Column("_AssignedTechnician")]
        public int? _AssignedTechnician { get; set; }

        [Column("_IsEscalated")]
        public bool? _IsEscalated { get; set; }

        [Column("_ExpectedCompletionDate")]
        public DateTime? _ExpectedCompletionDate { get; set; }

        [Column("_ClosedBy")]
        public int? _ClosedBy { get; set; }

        [Column("_ResolvedBy")]
        public int? _ResolvedBy { get; set; }

        [Column("_ClosedDate")]
        public DateTime? _ClosedDate { get; set; }

        [Column("_ResolvedDate")]
        public DateTime? _ResolvedDate { get; set; }

        [Column("_IsTicketGeneratedViaEmail")]
        public bool? _IsTicketGeneratedViaEmail { get; set; }

        [Column("_IsActive")]
        public bool? _IsActive { get; set; }

        [Column("_Created")]
        public DateTime _Created { get; set; }

        [Column("_Modified")]
        public DateTime _Modified { get; set; }

        [Column("_CreatedBy")]
        public int _CreatedBy { get; set; }

        [Column("_ModifiedBy")]
        public int _ModifiedBy { get; set; }

        [Column("_IsDuplicate")]
        public bool? _IsDuplicate { get; set; }

        [Column("_DuplicateTicketID")]
        public int? _DuplicateTicketID { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<_Attachment> _Attachment { get; set; }

        public virtual _Category _Category1 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<_Comment> _Comment { get; set; }

        public virtual _Priority _Priority1 { get; set; }

        public virtual _Status _Status1 { get; set; }

        public virtual _TicketType _TicketType { get; set; }

        public virtual _User _User { get; set; }

        public virtual _User _User1 { get; set; }

        public virtual _User _User2 { get; set; }

        public virtual _User _User3 { get; set; }

        public virtual _User _User4 { get; set; }

        public virtual _User _User5 { get; set; }
    }
}
