namespace TicketingSystem.DB.Database
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("_TicketType")]
    public partial class _TicketType
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public _TicketType()
        {
            _Ticket = new HashSet<_Ticket>();
        }

        [Key]
        [Column("_ID")]
        public int _ID { get; set; }

        [Column("_Title")]
        [Required]
        [StringLength(50)]
        public string _Title { get; set; }

        [Column("_Description")]
        public string _Description { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<_Ticket> _Ticket { get; set; }
    }
}
