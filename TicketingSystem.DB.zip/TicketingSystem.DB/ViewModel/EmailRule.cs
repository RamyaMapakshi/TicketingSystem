namespace TicketingSystem.DB.ViewModel
{
    public class EmailRule : Database._EmailRule
    {
        public int ID { get; set; }
        public string Rule { get; set; }
        public RuleType Type { get; set; }
    }
    public enum RuleType
    {
        Sender, Subject, Body, CC, Common
    }
}
