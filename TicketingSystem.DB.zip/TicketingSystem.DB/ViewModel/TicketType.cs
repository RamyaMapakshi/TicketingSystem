namespace TicketingSystem.DB.ViewModel
{
    public class TicketType : Database._TicketType
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
    }
}
