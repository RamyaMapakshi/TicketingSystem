namespace TicketingSystem.DB.ViewModel
{
    public class User:Database._User
    {
        public int ID { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public string EmployeeId { get; set; }
    }
}
